type Title = string;
type Author = string;
type Id = number;
type Availability = boolean;
type Year = number;

//Interface Book for the book properties
interface Book {
    title: Title;
    author: Author;
    id: Id;
    availability: Availability;
    year: Year;
    genre: Genre; 
}

//Enum Genre for different book genres
enum Genre {
    Fiction,
    History,
    Science,
    Biography
}

//Tuple type BookTuple for a book id and quantity pair
type BookTuple = [Id, number];

//Generic function getDetails<T> that can accept a book object or book tuple and returns the appropriate details string
function getDetails<T>(item: T): string {
    if (isBook(item)) {
        //Implement Type Assertion and Type Guards in your getDetails function
        const book = item as Book;
        return `Book Details:
                Title: ${book.title}
                Author: ${book.author}
                ID: ${book.id}
                Available: ${book.availability}
                Year: ${book.year}
                Genre: ${Genre[book.genre]}`;
    } else if (isBookTuple(item)) {
        const bookTuple = item as BookTuple;
        return `Book Tuple:
                ID: ${bookTuple[0]}
                Quantity: ${bookTuple[1]}`;
    } else {
        return "Invalid item type";
    }
}

// Type Guard to check if item is of type Book
function isBook(item: any): item is Book {
    return (item as Book).title !== undefined;
}

// Type Guard to check if item is of type BookTuple
function isBookTuple(item: any): item is BookTuple {
    return Array.isArray(item) && item.length === 2 && typeof item[0] === "number" && typeof item[1] === "number";
}

// Example usage:
const book: Book = {
    title: "The Great Gatsby",
    author: "F. Scott Fitzgerald",
    id: 1,
    availability: true,
    year: 1925,
    genre: Genre.Fiction
};

const bookTuple: BookTuple = [1, 3];

console.log(getDetails(book));
console.log(getDetails(bookTuple));
